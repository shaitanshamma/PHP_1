<?php
?>
<div class="foot">
    <p>© 2021 Brand All Rights Reserved.</p>
    <p id="123"></p>
    <div class="social_link">
        <a href="#" rel="nofollow" class="icon-button"><i class="fab fa-facebook-f"></i></a>
        <a href="#" rel="nofollow" class="icon-button"><i class="fa fa-instagram"></i></a>
        <a href="#" rel="nofollow" class="icon-button"><i class="fab fa-pinterest-p"></i></a>
        <a href="#" rel="nofollow" class="icon-button"><i class="fab fa-twitter"></i></a>
    </div>
</div>
